﻿using System.Web.Mvc;
using System.Web.Routing;
using AreasDemo.AreaLib;

namespace AreasDemo {
    // Note: For instructions on enabling IIS6 or IIS7 classic mode, 
    // visit http://go.microsoft.com/?LinkId=9394801

    public class MvcApplication : System.Web.HttpApplication {

        public static void RegisterRoutes(RouteCollection routes) {
            routes.IgnoreRoute("{resource}.axd/{*pathInfo}");

            routes.MapAreas("{controller}/{action}/{id}", 
                "AreasDemo", 
                new[]{ "Blogs", "Forums" });

            routes.MapRootArea("{controller}/{action}/{id}", 
                "AreasDemo", 
                new { controller = "Home", action = "Index", id = "" });

            //RouteDebug.RouteDebugger.RewriteRoutesForTesting(RouteTable.Routes);

        }

        protected void Application_Start() {
            ViewEngines.Engines.Clear();
            ViewEngines.Engines.Add(new AreaViewEngine());

            RegisterRoutes(RouteTable.Routes);
        }
    }
}