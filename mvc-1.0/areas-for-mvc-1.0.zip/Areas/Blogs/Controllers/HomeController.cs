﻿using System.Web.Mvc;

namespace AreasDemo.Areas.Blogs.Controllers {
    public class HomeController : Controller {
        public ActionResult Index() {
            return View();
        }

        public ActionResult Posts() {
            return View();
        }
    }
}
