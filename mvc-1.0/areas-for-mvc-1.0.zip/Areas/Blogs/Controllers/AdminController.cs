﻿using System.Web.Mvc;

namespace AreasDemo.Areas.Blogs.Controllers {
    public class AdminController : Controller {
        public ActionResult Index() {
            return View();
        }
    }
}
