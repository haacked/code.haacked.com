﻿using System.Web.Mvc;
using System.Web.Routing;
using IronRubyMvc.ViewEngine;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;

namespace IronRubyMvc.Tests.ViewEngine
{
    [TestClass]
    public class RubyViewEngineTests
    {
        [TestMethod]
        public void FindView_HavingViewSource_LooksUpViewFromViewSource() { 
            // arrange
            var routeData = new RouteData();
            routeData.Values.Add("controller", "home");
            routeData.Values.Add("action", "index");
            var controllerContext = new Mock<ControllerContext>();
            controllerContext.Setup(c => c.RouteData).Returns(routeData);
            var rubyViewSource = new Mock<IRubyViewSource>();
            rubyViewSource.Setup(s => s.FileExists(null, It.IsAny<string>())).Returns(true);
            rubyViewSource.Setup(s => s.GetViewContents(null, It.IsAny<string>())).Returns("This is a test");
            var engine = new RubyViewEngine(null, rubyViewSource.Object);

            // act
            ViewEngineResult result = engine.FindView(controllerContext.Object, "test", null, false);
            RubyView view = result.View as RubyView;

            // assert
            Assert.AreEqual("This is a test", view.Contents);
        }
    }
}
