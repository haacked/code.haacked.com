﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace IronRubyMvc.Tests.ViewEngine
{
    [TestClass]
    public class RubyViewTests
    {
        [TestMethod]
        public void Ctor_WithContents_SetsContents() { 
            // arrange, act
            var rubyView = new RubyView(null, "test", null);

            // assert
            Assert.AreEqual("test", rubyView.Contents);
        }
    }
}
