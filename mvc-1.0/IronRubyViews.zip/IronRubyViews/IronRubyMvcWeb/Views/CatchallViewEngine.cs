﻿namespace IronRubyMvcWeb.Views {
    using System.Web.Mvc;

    public class CatchallViewEngine : WebFormViewEngine
    {
        public override ViewEngineResult FindView(ControllerContext controllerContext, string viewName, string masterName, bool useCache) {
            controllerContext.Controller.ViewData.Add("View.Name", viewName);
            string virtualPath = string.Format("~/Views/{0}/{1}.rhtml", controllerContext.RouteData.Values["controller"], viewName);
            controllerContext.Controller.ViewData.Add("View.VirtualPath", virtualPath);
            return new ViewEngineResult(new WebFormView("~/Views/Shared/ViewCreate.aspx"), this);
        }
    }
}
