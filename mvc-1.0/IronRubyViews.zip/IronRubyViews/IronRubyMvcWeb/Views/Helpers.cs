﻿namespace IronRubyMvcWeb.Views {
    using System;
    using System.Linq;
    using System.Web;
    using System.Web.Mvc;
    using System.Web.Mvc.Html;
    using System.Web.Routing;
    using IronRubyMvcWeb.Infrastructure.RubyViews;
    using IronRubyViewEngine;

    public static class Helpers {

        public static string EditViewLink(this HtmlHelper htmlHelper) {
            object viewIdObject = htmlHelper.ViewData["View"] as View;
            if (viewIdObject != null) {
                var copiedRouteValues = new RouteValueDictionary(htmlHelper.ViewContext.RouteData.Values);
                copiedRouteValues.Add("editView", true);

                return "| " + htmlHelper.RouteLink("Edit View", copiedRouteValues, null);
            }
            return string.Empty;
        }

        public static void ModelPropertiesTable(this HtmlHelper htmlHelper, object o) {
            var properties = from property in o.GetType().GetProperties()
                             select new ModelPropertyInfo { 
                                Name = property.Name,
                                Type = property.PropertyType.Name,
                                Value = Convert.ToString(property.GetValue(o, null))
                             };
            htmlHelper.RenderPartial("ModelProperties", properties);
        }

        public static string ViewEditTitle(this HtmlHelper htmlHelper) {
            if (htmlHelper.ViewData["View"] != null) {
                return "Edit View";
            }
            return "Create View";
        }

        public static string ViewAction(this HtmlHelper htmlHelper) {
            if (htmlHelper.ViewData["View"] != null) {
                return "Edit";
            }
            return "Create";
        }

        public static MvcForm BeginViewEditForm(this HtmlHelper htmlHelper) {
            HttpRequestBase request = htmlHelper.ViewContext.HttpContext.Request;
            return htmlHelper.BeginForm(htmlHelper.ViewAction(), "View", new { redirectUrl = request.Path });
        }
    }

}
