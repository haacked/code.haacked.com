namespace IronRubyMvcWeb.Controllers {
    using System.Web.Mvc;
    using System.Linq;
    using IronRubyMvcWeb.Infrastructure.RubyViews;

    public class ViewController : Controller {
        [ValidateInput(false)]
        [AcceptVerbs(HttpVerbs.Post)]
        public ActionResult Create(View view, string redirectUrl) {
            RubyViewsDataContext context = new RubyViewsDataContext();
            context.Views.InsertOnSubmit(view);
            context.SubmitChanges();

            //TODO: Should only allow virtual paths and not fully qualified URLs
            return Redirect(redirectUrl);
        }
            
        [ValidateInput(false)]
        [AcceptVerbs(HttpVerbs.Post)]
        public ActionResult Edit(View view, string redirectUrl) {
            RubyViewsDataContext context = new RubyViewsDataContext();
            var dbView = context.Views.FirstOrDefault(v => v.Id == view.Id);
            dbView.Name = view.Name;
            dbView.Contents = view.Contents;
            dbView.VirtualPath = view.VirtualPath;
            context.SubmitChanges();

            //TODO: Should only allow virtual paths and not fully qualified URLs
            return Redirect(redirectUrl);
        }
    }
}
