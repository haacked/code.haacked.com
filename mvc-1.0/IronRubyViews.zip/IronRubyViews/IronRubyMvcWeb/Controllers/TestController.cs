﻿namespace IronRubyMvcWeb.Controllers {
    using System;
    using System.Web.Mvc;
    using IronRubyMvcWeb.Infrastructure;

    [Layout("layout")]
    public class TestController : Controller {
        public ActionResult Index() {
            return View(new { salutation = "This is the Test Controller Index", numbers = new int[]{1,2,3,4}});
        }

        public ActionResult FooBar()
        {
            return View(new { salutation = "This is the Test Controller Index", numbers = new int[] { 1, 2, 3, 4 } });
        }

        public ActionResult FunWithScripting()
        {
            var someData = new { 
                salutation = "Are you having fun with scripting yet?", 
                theDate = DateTime.Now,
                numbers = new int[] { 1, 2, 3, 4 } 
            };

            return View(someData);
        }
    }
}
