﻿namespace IronRubyMvcWeb.Controllers {
    using System.Web.Mvc;
    using IronRubyMvcWeb.Infrastructure;
    using System;

    [Layout("layout")]
    public class HomeController : Controller {
        public ActionResult Index() {
            return View(new {salutation = "Hello World"});
        }
    }
}
