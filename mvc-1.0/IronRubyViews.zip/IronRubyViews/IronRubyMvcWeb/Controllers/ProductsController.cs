﻿namespace IronRubyMvcWeb.Controllers {
    using System.Linq;
    using System.Web.Mvc;
    using IronRubyMvcWeb.Infrastructure;
    using IronRubyMvcWeb.Models.Northwind;

    [LayoutAttribute("layout")]
    public class ProductsController : Controller {
        NorthwindDataContext _context;

        public ActionResult Index() {
            return View(_context.Categories);
        }

        public ActionResult Edit(int id) {
            
            Product product = _context.Products.FirstOrDefault(p => p.ProductID == id);
            return View(product);
        }

        public ProductsController() {
            _context = new NorthwindDataContext();
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing) {
                if (_context != null) {
                    _context.Dispose();
                }
            }
        }
    }
}
