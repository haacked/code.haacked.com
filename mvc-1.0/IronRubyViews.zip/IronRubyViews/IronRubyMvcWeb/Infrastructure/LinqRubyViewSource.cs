﻿namespace IronRubyMvcWeb.Infrastructure {
    using System;
    using System.Linq;
    using System.Web.Mvc;
    using IronRubyMvc.ViewEngine;
    using IronRubyMvcWeb.Infrastructure.RubyViews;

    public class LinqRubyViewSource : IRubyViewSource, IDisposable
    {
        RubyViewsDataContext _db = new RubyViewsDataContext();

        public string GetViewContents(ControllerContext controllerContext, string path) {
            var view = _db.Views.FirstOrDefault(v => v.VirtualPath == path);
            if (view != null) {
                controllerContext.Controller.ViewData["View"] = view;
                return view.Contents;
            }
            return null;
        }

        public bool FileExists(ControllerContext requestContext, string path) {
            var view = _db.Views.FirstOrDefault(v => v.VirtualPath == path);
            return view != null;
        }

        protected virtual void Dispose(bool disposing) {
            if (disposing) {
                RubyViewsDataContext context = _db;
                if (context != null)
                {
                    context.Dispose();
                }
            }
        }
    
        void IDisposable.Dispose() {
            Dispose(true);
        }
        
        ~LinqRubyViewSource() {
            Dispose(false);
        }
    }
}
