﻿namespace IronRubyMvcWeb.Infrastructure {
    using System.Web.Mvc;

    public class LayoutAttribute : ActionFilterAttribute {
        public LayoutAttribute(string layoutName) {
            LayoutName = layoutName;
        }

        public string LayoutName { 
            get; set; 
        }

        public override void OnResultExecuting(ResultExecutingContext filterContext) {
            var result = filterContext.Result as ViewResult;
            if (result != null && string.IsNullOrEmpty(result.MasterName)) {
                result.MasterName = LayoutName;
            }
        }
    }
}
