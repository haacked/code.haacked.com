﻿namespace IronRubyMvcWeb {
    using System;
    using System.Web;
    using System.Web.Mvc;
    using System.Web.Routing;
    using IronRubyBootstrapper;
    using IronRubyMvc;
    using IronRubyMvcWeb.Infrastructure;
    using IronRubyMvcWeb.Views;
    using Microsoft.Scripting.Hosting;

    public class GlobalApplication : HttpApplication {
        public static void RegisterRoutes(RouteCollection routes) {
            routes.IgnoreRoute("{resource}.axd/{*pathInfo}");

            routes.MapRoute(
                "Default",                                              // Route name
                "{controller}/{action}/{id}",                           // URL with parameters
                new { controller = "Home", action = "Index", id = "" }  // Parameter defaults
            );
        }

        protected void Application_Start(object sender, EventArgs e) {
            RegisterRoutes(RouteTable.Routes);

            var assmemblyTypes = new[] { 
                    typeof(object), 
                    typeof(Uri), 
                    typeof(Controller)};

            ScriptRuntime scriptRuntime = Bootstrap.CreateIronRubyRuntime(assmemblyTypes, true, true);
            var rubyDatabaseViewEngine = new RubyViewEngine(scriptRuntime, new LinqRubyViewSource());
            rubyDatabaseViewEngine.ViewLocationCache = DefaultViewLocationCache.Null;
            ViewEngines.Engines.Insert(0, rubyDatabaseViewEngine);
            var catchallViewEngine = new CatchallViewEngine();
            catchallViewEngine.ViewLocationCache = DefaultViewLocationCache.Null;
            ViewEngines.Engines.Add(catchallViewEngine);
        }
    }
}