﻿namespace IronRubyMvc.ViewEngine {
    using System.Web.Mvc;

    public interface IRubyViewSource {
        string GetViewContents(ControllerContext controllerContext, string path);
        bool FileExists(ControllerContext controllerContext, string path);
    }
}
