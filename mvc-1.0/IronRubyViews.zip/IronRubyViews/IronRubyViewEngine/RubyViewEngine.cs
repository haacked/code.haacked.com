﻿namespace IronRubyMvc {
    using System;
    using System.IO;
    using System.Web.Mvc;
    using System.Web.Routing;
    using IronRubyMvc.ViewEngine;
    using Microsoft.Scripting.Hosting;

    public class RubyViewEngine : VirtualPathProviderViewEngine {
        public RubyViewEngine() {
            PartialViewLocationFormats = new string[] {
                "~/Views/{1}/_{0}.rhtml", 
                "~/Views/Shared/_{0}.rhtml"
            };

            ViewLocationFormats = new string[] { 
                "~/Views/{1}/{0}.rhtml", 
                "~/Views/Shared/{0}.rhtml", 
            };

            MasterLocationFormats = new string[] { 
                "~/Views/{1}/{0}.rhtml", 
                "~/Views/Shared/{0}.rhtml"
            };
        }

        public RubyViewEngine(ScriptRuntime scriptRuntime, IRubyViewSource rubyViewSource) : this() {
            RubyViewSource = rubyViewSource;
            ScriptRuntime = scriptRuntime;
        }

        protected IRubyViewSource RubyViewSource {
            get;
            private set;
        }

        protected ScriptRuntime ScriptRuntime {
            get;
            private set;
        }

        string GetContents(ControllerContext controllerContext, string path) {
            if (RubyViewSource != null) {
                string contents = RubyViewSource.GetViewContents(controllerContext, path);
                if (!String.IsNullOrEmpty(contents)) {
                    return contents;
                }
            }

            using (var stream = VirtualPathProvider.GetFile(path).Open())
            using (var reader = new StreamReader(stream)) {
                return reader.ReadToEnd();
            }
        }

        protected override bool FileExists(ControllerContext controllerContext, string virtualPath) {
            if (RubyViewSource != null && RubyViewSource.FileExists(controllerContext, virtualPath)) {
                return true;
            }
            return base.FileExists(controllerContext, virtualPath);
        }

        RubyView GetRubyMasterView(ControllerContext controllerContext, string virtualPath) {
            if (String.IsNullOrEmpty(virtualPath))
                return null;

            string viewContents = GetContents(controllerContext, virtualPath);
            return new RubyView(ScriptRuntime, viewContents, null);
        }

        IView GetView(ControllerContext controllerContext, string virtualPath, RubyView masterView) {
            if (String.IsNullOrEmpty(virtualPath))
                return null;

            string viewContents = GetContents(controllerContext, virtualPath);
            if (String.Equals(controllerContext.HttpContext.Request.QueryString["editView"], "true", StringComparison.OrdinalIgnoreCase)) {
                return new WebFormView("~/Views/Shared/ViewCreate.aspx");
            }
            return new RubyView(ScriptRuntime, viewContents, masterView);
        }

        protected override IView CreatePartialView(ControllerContext controllerContext, string partialPath) {
            return GetView(controllerContext, partialPath, null);
        }

        protected override IView CreateView(ControllerContext controllerContext, string viewPath, string masterPath) {
            RubyView masterView = GetRubyMasterView(controllerContext, masterPath);
            return GetView(controllerContext, viewPath, masterView);
        }
    }
}
