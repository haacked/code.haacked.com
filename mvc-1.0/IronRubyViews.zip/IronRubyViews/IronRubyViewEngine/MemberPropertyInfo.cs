﻿namespace IronRubyViewEngine
{
    public class ModelPropertyInfo
    {
        public string Name { get; set; }
        public string Type { get; set; }
        public string Value { get; set; }
    }
}
