﻿using System.Web;
using System.Web.Routing;
using Moq;
using TddDemo.Web;
using Xunit;

namespace UnitTests
{
    public class RouteTests
    {
        [Fact]
        public void CanMapNormalControllerActionRoute()
        {
            var routes = new RouteCollection();
            MvcApplication.RegisterRoutes(routes);

            var httpContextMock = new Mock<HttpContextBase>();
            httpContextMock.Setup(c => c.Request.AppRelativeCurrentExecutionFilePath)
                .Returns("~/product/list");

            RouteData routeData = routes.GetRouteData(httpContextMock.Object);
            Assert.NotNull(routeData);
            Assert.Equal("product", routeData.Values["Controller"]);
            Assert.Equal("list", routeData.Values["action"]);
        }

        [Fact]
        public void RouteHasDefaultActionWhenUrlWithoutAction()
        {
            var routes = new RouteCollection();
            MvcApplication.RegisterRoutes(routes);

            RouteTestHelpers.AssertRoute(routes, "~/product", new {controller = "product", action = "Index"});
        }
    }
}