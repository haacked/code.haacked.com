﻿namespace StringLib
{
    public interface ITextExpression
    {
        string Eval(object o);
    }
}
