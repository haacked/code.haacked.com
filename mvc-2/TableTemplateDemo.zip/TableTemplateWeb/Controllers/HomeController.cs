﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using TableTemplateWeb.Models;

namespace TableTemplateWeb.Controllers
{
    [HandleError]
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            var books = new List<Book>
            {
                new Book { Id = 1, Title = "1984", Author = "George Orwell", PublishDate = DateTime.Now },
                new Book { Id = 2, Title = "Fellowship of the Ring", Author = "J.R.R. Tolkien", PublishDate = DateTime.Now },
                new Book { Id = 3, Title = "Professional ASP.NET MVC 2", Author = "Scott, Rob, Phil, Jon", PublishDate = DateTime.Now },
                new Book { Id = 4, Title = "Code Complete", Author = "Steve McConnell", PublishDate = DateTime.Now },
                new Book { Id = 5, Title = "To Kill a Mockingbird", Author = "Harper Lee", PublishDate = DateTime.Now }
            };
            return View(books);
        }
    }
}
