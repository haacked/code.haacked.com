﻿using System.Web;
using System.Web.Mvc;
using System.Web.Routing;

namespace EditableRoutesWeb
{
    public class MvcApplication : HttpApplication
    {
        protected void Application_Start()
        {
            AreaRegistration.RegisterAllAreas();
            
            // Use the following if you have FULL Trust
            // RouteTable.Routes.RegisterRoutes(HttpContext.Current.Server);

            // Use this for MEDIUM Trust
            RouteTable.Routes.RegisterAppCodeRoutes();
        }
    }
}