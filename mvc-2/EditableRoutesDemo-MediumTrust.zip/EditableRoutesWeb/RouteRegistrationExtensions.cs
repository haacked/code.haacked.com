﻿using System;
using System.IO;
using System.Web;
using System.Web.Compilation;
using System.Web.Routing;

namespace EditableRoutesWeb
{
    public static class RouteRegistrationExtensions
    {
        // Use this for Full trust for Routes.cs in the ~/Config directory.
        public static void RegisterRoutes(this RouteCollection routes, HttpServerUtility server)
        {
            string path = server.MapPath("~/Config/");
            var watcher = new FileSystemWatcher(path);
            watcher.Changed += (o, e) =>
            {
                if(String.Equals(e.Name, "Routes.cs", StringComparison.OrdinalIgnoreCase))
                {
                    routes.ReloadRoutes();
                }
            };
            watcher.EnableRaisingEvents = true;

            routes.ReloadRoutes();
        }

        // Use this for Medium trust for Routes.cs in the ~/App_Code directory.
        public static void RegisterAppCodeRoutes(this RouteCollection routes) {
            var type = BuildManager.GetType("Routes", false/*throwOnError*/);
            if (type == null)
            {
                throw new InvalidOperationException("Could not find a type Routes in the App_Code directory");
            }

            var registrar = Activator.CreateInstance(type) as IRouteRegistrar;
            if (registrar == null)
            {
                throw new InvalidOperationException("Could not find an instance of IRouteRegistrar");
            }

            registrar.RegisterRoutes(RouteTable.Routes);
        }

        static void ReloadRoutes(this RouteCollection routes)
        {
            var assembly = BuildManager.GetCompiledAssembly("~/Config/Routes.cs");
            var registrar = assembly.CreateInstance("Routes") as IRouteRegistrar;
            if(registrar == null)
            {
                throw new InvalidOperationException("Could not find a class named 'Routes' of type 'IRouteRegistrar' at the location '~/Config/Routes.cs'");
            }
            using(routes.GetWriteLock())
            {
                routes.Clear();
                registrar.RegisterRoutes(routes);
            }
        }
    }
}
