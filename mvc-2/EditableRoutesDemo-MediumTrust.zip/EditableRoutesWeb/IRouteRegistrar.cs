﻿using System.Web.Routing;

namespace EditableRoutesWeb
{
    public interface IRouteRegistrar
    {
        void RegisterRoutes(RouteCollection routes);
    }
}
