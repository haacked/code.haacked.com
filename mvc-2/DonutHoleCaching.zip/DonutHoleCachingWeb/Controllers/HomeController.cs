﻿using System.Web.Mvc;
using DonutHoleCachingWeb.Models;

namespace DonutHoleCachingWeb.Controllers
{
    [HandleError]
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            var jokes = new[] { 
                new Joke {Title = "Two cannibals are eating a clown"},
                new Joke {Title = "One turns to the other and asks"},
                new Joke {Title = "Does this taste funny to you?"}
            };

            return View(jokes);
        }
    }
}
