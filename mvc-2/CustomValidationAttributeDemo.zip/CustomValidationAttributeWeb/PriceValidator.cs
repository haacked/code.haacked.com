﻿using System.Web.Mvc;
using System.Collections.Generic;

namespace CustomValidationAttributeWeb {
    public class PriceValidator : DataAnnotationsModelValidator<PriceAttribute> {

        double _minPrice;
        string _message;

        public PriceValidator(ModelMetadata metadata, ControllerContext context
            , PriceAttribute attribute)
            : base(metadata, context, attribute) {
            _minPrice = attribute.MinPrice;
            _message = attribute.ErrorMessage;
        }

        public override IEnumerable<ModelClientValidationRule> GetClientValidationRules() {
            var rule = new ModelClientValidationRule {
                ErrorMessage = _message,
                ValidationType = "price"
            };
            rule.ValidationParameters.Add("min", _minPrice);

            return new[] { rule };
        }
    }
}