﻿using System.Web.Mvc;
using CustomValidationAttributeWeb.Models;

namespace CustomValidationAttributeWeb.Controllers {
    [HandleError]
    public class HomeController : Controller {
        public ActionResult Index() {
            return View();
        }

        [HttpPost]
        public ActionResult Index(ProductViewModel model) {
            return View(model);
        }

        public ActionResult JQueryValidation()
        {
            return View();
        }
    }
}
