﻿using System.ComponentModel.DataAnnotations;

namespace CustomValidationAttributeWeb.Models {
    public class ProductViewModel {
        [Required(ErrorMessage="This field is required")]
        public string Title { get; set; }
        [Price(MinPrice=3.99, ErrorMessage = "Price must end in .99 and be larger than 3.99")]
        public double Price { get; set; }
    }
}
