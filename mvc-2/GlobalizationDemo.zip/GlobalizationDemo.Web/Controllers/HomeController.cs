﻿using System.Web.Mvc;
using GlobalizationDemo.Web.Models;

namespace GlobalizationDemo.Web.Controllers
{
    [HandleError]
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Index(Product product)
        {
            if (ModelState.IsValid) {
                return RedirectToAction("Index");
            }
            return View();
        }
    }
}
