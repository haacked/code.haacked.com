﻿using System;
using System.ComponentModel.DataAnnotations;

namespace GlobalizationDemo.Web.Models
{
    public class Product
    {
        [Required]
        public string Title { get; set; }

        [Range(100, 1000)]
        public int QuantityInStock { get; set; }

        public decimal Cost { get; set; }
    }
}