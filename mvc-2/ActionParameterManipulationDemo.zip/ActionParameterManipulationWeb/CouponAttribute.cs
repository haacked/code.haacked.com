﻿using System;
using System.Web.Mvc;
using ActionParameterManipulationWeb.Models;

namespace ActionParameterManipulationWeb
{
    public class CouponAttribute : ActionFilterAttribute
    {
        public override void OnActionExecuting(ActionExecutingContext filterContext)
        {
            var productModel = filterContext.ActionParameters["product"] as ProductViewModel;
            if(productModel != null)
            {
                if(DateTime.Now.Year == 2010 && String.IsNullOrEmpty(productModel.CouponCode))
                {
                    // contrived scenario.
                    productModel.CouponCode = "XYZ";
                }
            }
            base.OnActionExecuting(filterContext);
        }
    }
}
