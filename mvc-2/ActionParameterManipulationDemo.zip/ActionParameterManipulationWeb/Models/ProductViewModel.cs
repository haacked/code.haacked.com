﻿
using System.Web.Mvc;

namespace ActionParameterManipulationWeb.Models
{
    [Bind(Exclude="CouponCode")]
    public class ProductViewModel
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public string CouponCode { get; set; }
    }
}
