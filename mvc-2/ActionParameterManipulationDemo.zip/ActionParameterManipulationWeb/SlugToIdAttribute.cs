﻿using System.Collections.Generic;
using System.Web.Mvc;

namespace ActionParameterManipulationWeb
{
    public class SlugToIdAttribute : ActionFilterAttribute
    {
        static readonly IDictionary<string, int> SlugIds = new Dictionary<string, int>
        {
            {"this-is-a-slug", 100}, 
            {"another-slug", 101}, 
            {"and-another", 102}
        };

        public override void OnActionExecuting(ActionExecutingContext filterContext)
        {
            var slug = filterContext.RouteData.Values["slug"] as string;
            if(slug != null)
            {
                int id;
                SlugIds.TryGetValue(slug, out id);
                filterContext.ActionParameters["id"] = id;
            }
            base.OnActionExecuting(filterContext);
        }
    }
}
