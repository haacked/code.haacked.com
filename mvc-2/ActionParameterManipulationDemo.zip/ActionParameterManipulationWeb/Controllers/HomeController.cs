﻿using System.Web.Mvc;
using ActionParameterManipulationWeb.Models;

namespace ActionParameterManipulationWeb.Controllers
{
    public class HomeController : Controller
    {
        //
        // GET: /Home/

        public ActionResult Index()
        {
            return View();
        }

        [SlugToId]
        public ActionResult Content(int id)
        {
            var slug = RouteData.Values["slug"] as string;
            ViewData["slug"] = slug;
            ViewData["id"] = id;
            return View();
        }

        [HttpPost]
        [Coupon]
        public ActionResult ProductView(ProductViewModel product)
        {
            return View(product);
        }
    }
}
