﻿using System.Web.Mvc;


namespace MvcApplication1.Controllers {
    public class HomeController : Controller {
        public string Index() {
            return @"<ul>
                        <li><a href=""/home/WebAppAssemblyVersion"">Web App Assembly Version</a></li>
                        <li><a href=""/home/ClassLibAssemblyVersion"">Class Lib Assembly Version</a></li>
                        <li><a href=""/home/ClassLibAssemblyVersionFixed"">Class Lib Assembly Version (Fixed)</a></li>
                    </ul>";
        }

        //public string WebAppAssemblyVersion() {
        //    return Assembly.GetExecutingAssembly().GetName().Version.ToString();
        //}

        public string ClassLibAssemblyVersion() {
            return ClassLibrary1.Class1.GetExecutingAssemblyVersion();
        }

        //public string ClassLibAssemblyVersionFixed() {
        //    return ClassLibrary1.Class1.GetExecutingAssemblyVersionFixed();
        //}
    }
}
