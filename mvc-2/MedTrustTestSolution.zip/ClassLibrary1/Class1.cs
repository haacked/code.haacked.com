﻿using System.Reflection;
using System.Security;

[assembly: SecurityTransparent]
namespace ClassLibrary1 {
    public static class Class1 {
        public static string GetExecutingAssemblyVersion() {
            return Assembly.GetExecutingAssembly().GetName().Version.ToString();
        }

        public static string GetExecutingAssemblyVersionFixed() {
            return new AssemblyName(typeof(Class1).Assembly.FullName).Version.ToString();
        }
    }
}
