﻿namespace JSONMvcSample.Models {
    using System;

    [Serializable]
    public class PersonViewModel {
        public string Message { get; set; }
    }
}