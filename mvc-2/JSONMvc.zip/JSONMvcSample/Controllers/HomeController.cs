﻿namespace JSONMvcSample.Controllers {
    using System.Linq;
    using System.Web.Mvc;
    using Models;

    [HandleError]
    public class HomeController : Controller {
        public ActionResult Index() {
            return View();
        }

        [HttpPost]
        public ActionResult Save(PersonInputModel inputModel) {
            if (ModelState.IsValid)
            {
                string message = string.Format("Created user '{0}' aged '{1}' in the system.", inputModel.Name, inputModel.Age);
                return Json(new PersonViewModel { Message = message });
            }
            else {
                string errorMessage = "<div class=\"validation-summary-errors\">The following errors occurred:<ul>";
                foreach (var key in ModelState.Keys) {
                    var error = ModelState[key].Errors.FirstOrDefault();
                    if (error != null) {
                        errorMessage += "<li class=\"field-validation-error\">" + error.ErrorMessage + "</li>";
                    }
                }
                errorMessage += "</ul>";
                return Json(new PersonViewModel { Message = errorMessage });
            }
        }
    }
}